<footer class="site-footer">
  <div class="site-footer-legal">© ٢٠١٩ <a href="/">ورشتي</a></div>
  <div class="site-footer-right">
  </div>
</footer>